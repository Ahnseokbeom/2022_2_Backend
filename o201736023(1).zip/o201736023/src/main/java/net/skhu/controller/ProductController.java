package net.skhu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import net.skhu.entity.Product;
import net.skhu.repository.CategoryRepository;
import net.skhu.repository.ProductRepository;

@Controller
@RequestMapping("exam")
public class ProductController {
	@Autowired CategoryRepository CR;
	@Autowired ProductRepository PR;
	
	@RequestMapping("list1")
	public String list1(Model model) {
		List<Product> products = PR.findAll();
		model.addAttribute("products",products);
		return "exam/list1";
	}
	@RequestMapping("list1?title={title}")
	public String list1(Model model, String title) {
		List<Product> pro = PR.findByTitleStartsWith(title);
		model.addAttribute("pro",pro);
		return "exam/list1?title={title}";
	}
}
