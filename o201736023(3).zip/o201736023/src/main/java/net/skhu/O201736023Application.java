package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class O201736023Application {

	public static void main(String[] args) {
		SpringApplication.run(O201736023Application.class, args);
	}

}
