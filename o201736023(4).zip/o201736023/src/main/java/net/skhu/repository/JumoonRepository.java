package net.skhu.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.skhu.entity.Jumoon;

public interface JumoonRepository extends JpaRepository<Jumoon, Integer>{

}
